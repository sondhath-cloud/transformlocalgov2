# TransformLocalGov Website - Deployment Package

**Created:** January 2025  
**Version:** 2.0  
**Structure:** Organized with all files under main/ directory

## What's Included

This deployment package contains everything needed to deploy your TransformLocalGov website:

### Core Website Files
- **index.html** - Homepage
- **about.html** - About page
- **apps.html** - Apps showcase
- **careers.html** - Careers page
- **contact.html** - Contact page
- **custom-tools.html** - Custom tools page
- **digital-adoption.html** - Digital adoption page
- **facilitation.html** - Facilitation services
- **order.html** - Order services page
- **resources.html** - Resources page
- **services.html** - Services page
- **subscribe.html** - Subscription page
- **success.html** - Payment success page
- **website-request.html** - Website request page

### Backend Files
- **api/** - All PHP API handlers
  - contact.php - Contact form handler
  - create-customer.php - Stripe customer creation
  - create-subscription.php - Stripe subscription creation
  - create-order-checkout.php - Stripe order checkout
  - careers-handler.php - Career application handler
  - custom-tools-handler.php - Custom tools handler
  - website-request-handler.php - Website request handler
  - subscribe-handler.php - Newsletter handler
  - order-handler.php - Order consultation handler
  - config.sample.php - Configuration template
- **stripe-php-master/** - Complete Stripe PHP library

### Assets
- **assets/images/** - All optimized images
- **assets/logos/** - Client logos
- **script.js** - Main JavaScript file
- **styles.css** - Main CSS file

### Demo Components
- **demos/** - Interactive demo components

### Database
- **database_schema.sql** - Complete database setup script

## Deployment Instructions

### For SiteWorks Hosting:

1. **Upload Files**
   - Upload all files to your `public_html` directory
   - Maintain the folder structure

2. **Database Setup**
   - Create a MySQL database in cPanel
   - Run `database_schema.sql` to create all tables
   - Create database user and assign permissions

3. **Configuration**
   - Copy `api/config.sample.php` to `api/config.php`
   - Add your database credentials
   - Add your Stripe API keys (if using payments)

4. **SSL Setup**
   - Enable SSL certificate in cPanel
   - Force HTTPS redirect

### File Structure After Deployment:
```
public_html/
├── index.html
├── about.html
├── [all HTML pages]
├── script.js
├── styles.css
├── api/
│   ├── config.php (you create this)
│   └── [all PHP handlers]
├── assets/
│   ├── images/
│   └── logos/
├── demos/
└── stripe-php-master/
```

## Features

- ✅ Responsive design
- ✅ Contact form with database storage
- ✅ Stripe payment integration
- ✅ Newsletter subscription
- ✅ Career application system
- ✅ Custom tools request system
- ✅ Website request system
- ✅ SSL ready
- ✅ Mobile optimized

## Support

For deployment assistance, refer to the documentation in the `md/` folder or contact the development team.

---
**TransformLocalGov Website v2.0**  
Ready for deployment!
